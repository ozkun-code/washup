<?php

namespace App\Livewire\Auth;

use Illuminate\Support\Facades\Auth;
use Livewire\Component;

class Login extends Component
{

    public $email;
    public $password;

    
public function login() {
    $valid = $this->validate([
        'email' => 'required|email',
        'password' => 'required'
    ]);

    if (!Auth::attempt($valid)) {
        $this->addError('Errors', 'Credentials do not match.');
    } else {
        $user = Auth::user();
        if ($user->role == 'owner' || $user->role == 'admin') {
            emotify('success', 'Halo selamat datang ' . $user->name);
            $this->redirect(route('home'),true);
        } else {
            emotify('error', 'You are not authorized to login.');
        }
    }
}

    public function render()
    {
        return view('livewire.auth.login');
    }
}