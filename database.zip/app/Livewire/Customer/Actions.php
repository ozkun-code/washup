<?php

namespace App\Livewire\Customer;

use App\Livewire\Forms\CustomerForm;
use App\Models\User;
use App\Models\Customer;
use Illuminate\Support\Facades\Hash;
use Livewire\Component;
use Livewire\Attributes\On;
use Illuminate\Validation\ValidationException;

use Livewire\WithFileUploads;

class Actions extends Component
{
    use WithFileUploads;


    public $show = false;
    
    public ?User $user = null;
    
    public CustomerForm $form;

    #[On('createCustomer')]

    public function createCustomer()
    {
        $this->show = true;
    }

    #[On('editCustomer')]

    public function editCustomer(Customer $customer)
    {   
        

        $this->form->setCustomer($customer);
        // dd($this->form);
        $this->show = true;
        $this->dispatch('reload');

    }
    #[On('deletCustomer')]

    public function deleteCustomer(Customer $customer)
{   
    
    // Retrieve the associated user
    $user = User::find($customer->user_id);

    // Delete the customer
    $customer->delete();

    // Delete the associated user
    $user->delete();

    $this->dispatch('reload');
}

public function simpan()
{
    try {
        
       
        if ($this->form->user_id === null) {
            $this->form->store();
            emotify('success', 'Data berhasil disimpan');
        } else {
            $this->form->update();
            emotify('success', 'Data berhasil diperbarui');
        }
    } catch (\Exception $e) {
       
        emotify('error', 'Terjadi kesalahan Email atau contact sudah digunakan'. $e->getMessage() );
    }

    return redirect()->route('customer.index');
}
    public function closeModal()
    {
        $this->show = false;
        $this->form->reset();
    }

    public function render()
    {
        return view('livewire.customer.actions');
    }
}
