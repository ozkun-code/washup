<div>
    <input type="checkbox" class="modal-toggle" <?php if($show): echo 'checked'; endif; ?>/>
<div class="modal" role="dialog">
  <form class="modal-box" wire:submit="simpan">
    <h3 class="font-bold text-lg">Form Add Customer!</h3>
    <div class="py-4 space-y-2">
        <label class="form-control">
            <div class="label">
              <span class="label-text">Nama Customer</span>
            </div>
            <input type="text" placeholder="Type here" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['input input-bordered', 'input-error' => $errors->first('form.name')]); ?>" wire:model="form.name" />
          </label>
          <label class="form-control">
            <div class="label">
              <span class="label-text">Contact</span>
            </div>
            <input type="text" placeholder="Type here" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['input input-bordered', 'input-error' => $errors->first('form.contact')]); ?>" wire:model="form.contact" />
          </label>
          <label class="form-control">
            <div class="label">
                <span class="label-text">User Email</span>
            </div>
            <input type="email" placeholder="Type here" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['input input-bordered', 'input-error' => $errors->first('form.user_email')]); ?>" wire:model="form.user_email" />
        </label>
        <input type="hidden"  wire:model="form.user_id" />
      

    </div>
    <div class="modal-action justify-between">
      <button  type="button" class="btn btn-ghost" wire:click="closeModal">Close!</button>
      <button class="btn btn-primary">
        <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tabler-check'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
        <span>Save</span>
      </button>
    </div>
  </form>
</div>
</div>
<?php /**PATH C:\laragon\www\washup-app\resources\views/livewire/customer/actions.blade.php ENDPATH**/ ?>