<div>
    <input type="checkbox" class="modal-toggle" <?php if($show): echo 'checked'; endif; ?> />
    <div class="modal" role="dialog">
        <div class="modal-box">
            <h3 class="font-bold text-lg">Detail Transaksi</h3>
            <div class="py-4 space-y-4">
                <div class="flex flex-col">
                    <div class="text-sm opacity-50">Tangggal Transaksi</div>
                    <div><?php echo e($transaksi?->created_at->format('d F Y H:i')); ?></div>
                </div>
                <div class="flex flex-col">
                    <div class="text-sm opacity-50">Nama Customer</div>
                    <div><?php echo e($transaksi?->customer?->name ?? '-'); ?></div>
                </div>
                <div class="flex flex-col">
                    <div class="text-sm opacity-50">Total Bayar</div>
                    <div>Rp<?php echo e(Number::format($transaksi?->price ?? 0)); ?></div>
                </div>
            </div>
            <div class="table-wraper">
                <table class="table">
                    <thead>
                        <th>Nama Service</th>
                        <th>Qty</th>
                        <th>Harga</th>
                    </thead>
                    <tbody>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = json_decode($transaksi?->items, true) ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key); ?></td>
                                <td><?php echo e($item['qty']); ?> <!--[if BLOCK]><![endif]--><?php if(isset($item['unit'])): ?>
                                        <?php echo e($item['unit']); ?>

                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                                <td><?php echo e(Number::format($item['price'])); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>
            </div>
            <div class="modal-action">
                <button type="button" wire:click="closeModal" class="btn btn-ghost">Close!</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\washup-app\resources\views/livewire/transaksi/detail.blade.php ENDPATH**/ ?>