<div class="page-wrapper">
    <div class="card max-w-lg mx-auto">
        <form class="card-body" wire:submit="simpan">
            <h3 class="card-title">Update Profile</h3>

            <div class="py-4 space-y-w">
                <label class="form-control">
                    <div class="label">
                      <span class="label-text">Nama lengkap</span>
                    </div>
                    <input type="text" placeholder="Type here" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['input input-bordered', 'input-error' => $errors->first('name')]); ?>" wire:model="name" />
                </label>
                <label class="form-control">
                    <div class="label">
                      <span class="label-text">Email</span>
                    </div>
                    <input type="text" placeholder="Type here" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['input input-bordered', 'input-error' => $errors->first('email')]); ?>" wire:model="email" autocomplete="email" />
                </label>
                <label class="form-control">
                    <div class="label">
                      <span class="label-text">Password</span>
                    </div>
                    <input type="password" placeholder="Isi apabila ingin merubah password" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['input input-bordered', 'input-error' => $errors->first('password')]); ?>" wire:model="password" />
                </label>
            </div>

            <div class="card-actions">
                <button class="btn btn-primary">
                    <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tabler-check'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                    <span>Simpan</span>
                </button>
            </div>
        </form>
    </div>
</div><?php /**PATH C:\laragon\www\washup-app\resources\views/livewire/auth/profile.blade.php ENDPATH**/ ?>