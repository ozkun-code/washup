<div>
    <input type="checkbox" class="modal-toggle" <?php if($show): echo 'checked'; endif; ?> />
    <div class="modal" role="dialog">
        <form class="modal-box" wire:submit="simpan">
            <h3 class="font-bold text-lg">Form Add Service!</h3>
            <div class="py-4 space-y-2">
                <div class="flex justify-center">
                    <label for="pickphoto" class="avatar">
                        <div class="w-32 rounded-2xl">
                            <img src="<?php echo e($photo ? $photo->temporaryUrl() : url('noimage.png')); ?>" />
                        </div>
                    </label>
                </div>
                <input type="file" class="hidden" id="pickphoto" wire:model="photo" />
                <label class="form-control">
                    <div class="label">
                        <span class="label-text">Service Name</span>
                    </div>
                    <input type="text" placeholder="Type here" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'input input-bordered',
                        'input-error' => $errors->first('form.name'),
                    ]); ?>" wire:model="form.name" />
                </label>
                <label class="form-control">
                    <div class="label">
                        <span class="label-text">Price</span>
                    </div>
                    <input type="number" placeholder="Type here" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'input input-bordered',
                        'input-error' => $errors->first('form.price'),
                    ]); ?>"
                        wire:model="form.price" />
                </label>
                <label class="form-control">
                    <div class="label">
                        <span class="label-text">Satuan</span>
                    </div>
                    <select type="number" placeholder="Type here" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'input input-bordered',
                        'input-error' => $errors->first('form.unit'),
                    ]); ?>" wire:model="form.unit">
                        <option value=""></option>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($unit); ?>"><?php echo e($unit); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </select>
                </label>
                <label class="form-control">
                    <div class="label">
                        <span class="label-text">Estimed Completion</span>
                    </div>
                    <input type="text" placeholder="Type here" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'input input-bordered',
                        'input-error' => $errors->first('form.estimated_completion_time'),
                    ]); ?>"
                        wire:model="form.estimated_completion_time" />
                </label>
                <label class="form-control">
                    <div class="label">
                        <span class="label-text">Description</span>
                    </div>
                    <textarea placeholder="Tulis keterangan Service disini" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'textarea textarea-bordered',
                        'input-error' => $errors->first('form.description'),
                    ]); ?>" wire:model="form.description"></textarea>
                </label>
            </div>
            <div class="modal-action justify-between">
                <button type="button" class="btn btn-ghost" wire:click="closeModal">Close!</button>
                <button class="btn btn-primary">
                    <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tabler-check'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                    <span>Save</span>
                </button>
            </div>
        </form>
    </div>
</div>
<?php /**PATH C:\laragon\www\washup-app\resources\views/livewire/service/actions.blade.php ENDPATH**/ ?>