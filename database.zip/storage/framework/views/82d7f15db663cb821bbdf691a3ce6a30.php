<svg class="size-5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
  <path d="M4 8l16 0" />
  <path d="M4 16l16 0" />
</svg><?php /**PATH C:\laragon\www\washup-app\storage\framework\views/ff2c9c710914465f719518d7790d8485.blade.php ENDPATH**/ ?>