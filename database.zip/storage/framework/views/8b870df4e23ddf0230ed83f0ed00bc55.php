<svg class="size-5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
  <path d="M12 3c7.2 0 9 1.8 9 9s-1.8 9 -9 9s-9 -1.8 -9 -9s1.8 -9 9 -9z" />
  <path d="M12 8v4" />
  <path d="M12 16h.01" />
</svg><?php /**PATH C:\laragon\www\washup-app\storage\framework\views/d7bbebaf5417822be76bc0d28b02e2d8.blade.php ENDPATH**/ ?>